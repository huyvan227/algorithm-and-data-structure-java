public class TestInteger{
    public static void main(String[] args){
        IntegerLinkedList list = new IntegerLinkedList();
        list.addFirst(10);
        list.addLast(2);
        list.addAfter(list.getHead(),5);
        list.addLast(7);
        list.print();
        System.out.println("Size --> " + list.size());
        System.out.println("Count even --> " + list.countEven());
        System.out.println("Count odd --> " + list.countOdd());
        System.out.println("Count prime --> " + list.countPrime());
        list.removeCurr(list.getFirstItem(2));
        list.print();
        System.out.println("Size --> " + list.size());
        System.out.println("Count even --> " + list.countEven());
        System.out.println("Count odd --> " + list.countOdd());
        list.addFirstEven(5);
        list.print();
        list.removeCurr(list.getFirstItem(10));
        list.addLast(2);
        list.addFirstEven(20);
        list.print();
        System.out.println("Max --> " + list.maximum());
        System.out.println("Min --> " + list.minimum());
        list.reverse();
        list.print();
        list.sortAscen();
        list.print(); 
        list.sortDescen();
        list.print();        
    }
}