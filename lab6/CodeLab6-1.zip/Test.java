public class Test {
    public static void main(String[] args)
    {
        MyLinkedList<Fraction> list = new MyLinkedList<>();
        list.addFirst(new Fraction(1, 2));
        list.addLast(new Fraction(3, 4));
        list.addAfter(list.getHead(),new Fraction(5,6));
        list.addLast(new Fraction(9, 4));
        
        list.print();
        System.out.println(list.size());
        list.removeCurr(list.getFirstItem(new Fraction(3, 4)));
        list.print();
        System.out.println(list.size());
        System.out.println(list.getHead());
    }
}