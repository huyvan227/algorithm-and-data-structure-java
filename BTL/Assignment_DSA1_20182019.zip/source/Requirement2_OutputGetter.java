//Sinh vien tuyet doi khong duoc sua file nay
public interface Requirement2_OutputGetter {
	public void setInputString(String inputString);
	public double getResultOfExpression();
}
