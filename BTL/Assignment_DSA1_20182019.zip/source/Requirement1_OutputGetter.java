//Sinh vien tuyet doi khong duoc sua file nay
public interface Requirement1_OutputGetter {
	public void setInputString(String inputString);
	public String getOutputString();
}
